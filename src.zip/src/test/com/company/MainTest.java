package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import main.com.company.Main;
import org.junit.jupiter.api.Test;

class MainTest {
    @Test
    public void testCompare() throws IOException {
        String cardDirName = "./extract/";
        BufferedImage img1 = ImageIO.read(
            new File(cardDirName + "20180821_094823.078_0x1FE201D8.png-0"));
        BufferedImage img2 = ImageIO.read(
            new File(cardDirName + "20180821_093307.189_0x1FE201D8.png-2"));
        int weight = Main.compareImages(img1, img2);
        System.out.println(weight);
    }
}
