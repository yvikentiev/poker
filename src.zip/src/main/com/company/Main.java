package main.com.company;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static final String COMPARE_DIR_NAME = "./compare/";
    public static final String TABLE_DIR_NAME = "./tables/";
    public static final String CARD_DIR_NAME = "./cards/";
    public static final String EXTRACT_DIR_NAME = "./extract/";
    private static Map<String, BufferedImage> cardsMap = new HashMap<String, BufferedImage>();

    public static void loadCards(String dir) throws IOException {
        Files.find(Paths.get(dir),
            Integer.MAX_VALUE,
            (filePath, fileAttr) -> fileAttr.isRegularFile())
            .forEach(path -> loadCard(path));
    }

    public static void loadCard(Path path)  {
        try {
            BufferedImage img = ImageIO.read(path.toFile());
            cardsMap.put(path.toString(), img);
            System.out.println(path.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int compareImages(BufferedImage img1, BufferedImage img2) {
        int weight = 0;
        for (int i = 3; i < img1.getWidth() - 3; i++)
            for (int j = 5; j < img1.getHeight() - 5; j++) {
                Color c1 = new Color(img1.getRGB(i, j));
                Color c2 = new Color(img2.getRGB(i, j));
                if (!c1.equals(c2)) {
                    weight++;
                }
            }
        return weight;
    }

    public static void main(String[] args) throws IOException {
        File fileName = new File(TABLE_DIR_NAME);
        File[] fileList = fileName.listFiles();
        loadCards(CARD_DIR_NAME);
        for (File file : fileList) {
            System.out.println(file);
            BufferedImage img = ImageIO.read(file);
            for (int i = 0; i < 6; i++) {
                int counter = i;
                BufferedImage img1 = img.getSubimage(
                    143 + i * 72, 585, 63, 89);
                ImageIO.write(img1, "png", new File(EXTRACT_DIR_NAME + file.getName() + "-"  + i));
                cardsMap.forEach((k, v) -> {
                    int weight = compareImages(img1, v);
                    if (weight < 100) {
                        try {
                            ImageIO.write(img1, "png", new File(COMPARE_DIR_NAME + file.getName() + "-"  + counter));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        System.out.println(file + "," +  counter + "," + k + "," + weight);
                    }
                });
            }
        }
    }
}
